package com.srkr.basics;
public class VariablesDemo {

	public static void main(String[] args) {
		int age = 0;

		int a = 2, b = 3, c = 5;

		long salary = 25_000_000_0000L;

		int _num = 17050;

		int $ = 7;

		char value = 'x';

		boolean isRaining = true;

		final double PI = 3.14;

		byte bite = (byte) 130;

		System.out.println("Byte : " + bite);
		System.out.println(salary);
		System.out.println(age);
		System.out.println(args);
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(Byte.MAX_VALUE);
		System.out.println(Byte.MIN_VALUE);
	}
}