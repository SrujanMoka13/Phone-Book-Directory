package com.srkr.oop;

public class PrintlnDemo {
	public static void main(String[] args) {
		System.out.println("123");
		System.out.println(123);
	}
}
//The method println(char[]) 
//is ambiguous for the type PrintStream
