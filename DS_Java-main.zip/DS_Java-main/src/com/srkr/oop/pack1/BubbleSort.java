package com.srkr.oop.pack1;

public class BubbleSort {
	static void sort(int[] arr) {
		
	}
	
	public static void main(String[] args) {
		
	}
}
