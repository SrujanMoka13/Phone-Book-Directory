package com.srkr.oop;

public class InterfacesTest {

	public static void main(String[] args) {
		Printer printer = new AdvPrinter();

		printer.print();
	}
}