package com.srkr.oop;

public class WrapperDemo {

	public static void main(String[] args) {
		int b = 5;
		int c = 7;

		System.out.println(Integer.toBinaryString(b));
		System.out.println(Integer.max(b, c));
	}
}