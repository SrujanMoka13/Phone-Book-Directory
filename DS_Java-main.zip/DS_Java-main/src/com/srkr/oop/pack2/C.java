package com.srkr.oop.pack2;

import com.srkr.oop.pack1.A;

public class C extends A{
	public static void main(String[] args) {

		C obj = new C();

		//System.out.println(obj.a);
		System.out.println(obj.b);
		System.out.println(obj.c);
		//System.out.println(obj.d);
	}
}