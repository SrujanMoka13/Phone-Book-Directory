package com.srkr.oop;

public class BasicPrinter implements Printer{

	@Override
	public void print() {
		System.out.println("Basic Printer");
	}
}