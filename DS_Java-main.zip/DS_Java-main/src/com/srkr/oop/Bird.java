package com.srkr.oop;

public abstract class Bird {

	abstract void fly();
}

class Eagle extends Bird {

	@Override
	void fly() {

	}

}

class Sparrow extends Bird {

	@Override
	void fly() {
		
	}

}
