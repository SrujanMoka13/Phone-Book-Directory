package com.srkr.oop;

public class AdvPrinter implements Printer {

	@Override
	public void print() {
		System.out.println("Adv Printer");
	}
}
