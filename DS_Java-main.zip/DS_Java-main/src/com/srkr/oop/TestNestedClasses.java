package com.srkr.oop;

public class TestNestedClasses {

	public static void main(String[] args) {
		Outer.Inner obj = new Outer.Inner(); 
		obj.show();
	}
}