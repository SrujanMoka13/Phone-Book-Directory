package com.srkr.oop;

public class Outer {

	static class Inner {

		void show() {
			System.out.println("show from Inner");
		}
	}
}