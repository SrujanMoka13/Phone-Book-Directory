package com.srkr.assignments;

public interface FiveG {
	void enable5G();
}
