package com.srkr.ds;

import java.util.LinkedList;

public class LinkedListDemo {

	public static void main(String[] args) {
		LinkedList<String> list = new LinkedList<>();

		list.add("Hi");
		list.add("Hello");
		list.add("How");

		System.out.println(list);
	}
}